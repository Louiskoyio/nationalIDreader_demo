package com.louiskoyio.nationalidreader;

public interface CallbackInterface {
    void done(Exception e);
}
